package com.example.jar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJarApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJarApplication.class, args);
	}
}
